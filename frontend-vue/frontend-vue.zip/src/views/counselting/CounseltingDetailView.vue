<template>
  <div class="trainer-detail"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTJ6yI5v-1UCyMx8CdTpABg9QzItPHcPLZh7_1ZnzOpTg&s" alt="">
    <div>name</div>
  <div class="detail-deco-bar"></div>
  <div>나이:</div> <div>경력:</div>
  </div>

</template>

<script>
export default {
}
</script>

<style scope>

</style>
