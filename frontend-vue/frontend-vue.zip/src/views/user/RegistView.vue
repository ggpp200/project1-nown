<template>
    <div class="container">
        <div class="container-center">
            <RegistForm></RegistForm>
        </div>
    </div>
</template>

<script>
import RegistForm from '@/components/user/RegistForm.vue'

export default {
  components: {
    RegistForm
  }
}
</script>
