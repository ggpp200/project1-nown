<template>
  <div> <ScheduleCaseInput/><ScheduleDateInput/> <ScheduleDateInput/> </div>
</template>

<script>
import ScheduleCaseInput from '@/components/trainer/scheduleCaseInput.vue'
import ScheduleDateInput from '@/components/trainer/scheduleDateInput.vue'
export default {
  components: { ScheduleCaseInput, ScheduleDateInput }

}

</script>

<style scope>

</style>
