<template>
  <div class="chatting"></div>
  <input type="text" class="blackinput">
</template>

<script>
export default {

}
</script>

<style scope>
.chatting{
  width: 300px;
  height: 600px;

  background: #000000;
}
.blackinput{
  font-family: 'MaruBuriOTF';
  font-style: normal;
  background-color: black;
  color: white;
  /* border-color: white; */
  border: solid 2px white;
  border-radius: 8px;
  width: 295px;
}

</style>
